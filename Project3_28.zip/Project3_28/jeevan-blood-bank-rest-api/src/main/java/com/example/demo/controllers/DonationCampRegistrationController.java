package com.example.demo.controllers;

import com.example.demo.repos.DonationCampRegistrationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.DonationCampRegistration;
import com.example.demo.services.DonationCampRegistrationService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@RestController
@RequestMapping(path = "/api/v3/")
@CrossOrigin(origins = "*")
public class DonationCampRegistrationController {

	@Autowired
	private DonationCampRegistrationService service;

	@Autowired
	private DonationCampRegistrationRepository donationCampRegistrationRepository;

	@PostMapping(path = "donorCamp")
	public ResponseEntity<Object> registerDonor(@RequestBody DonationCampRegistration registration) {
		try {
			DonationCampRegistration registrationResponse = this.service.registerDonor(registration);
			return ResponseEntity.status(HttpStatus.CREATED).body("Donor registered successfully! Registration ID: " + registrationResponse.getRegId());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to register donor: " + e.getMessage());
		}
	}

	@GetMapping(path = "track")
	public ResponseEntity<Object> getCount() {
		System.out.println("er");
		return ResponseEntity.ok().body(this.service.getCount());
	}

	@GetMapping(path = "slots/{date}")
	public ResponseEntity<List<DonationCampRegistration>> getBookingsByDate(
			@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
		LocalDateTime startOfDay = date.atStartOfDay();
		LocalDateTime endOfDay = date.atTime(LocalTime.MAX);
		List<DonationCampRegistration> bookings = donationCampRegistrationRepository.findBetweenDates(startOfDay, endOfDay);
		if (bookings.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(bookings);
		}
		return ResponseEntity.ok(bookings);
	}
}

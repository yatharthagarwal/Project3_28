package com.example.demo.services;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.DonationCampRegistration;
import com.example.demo.repos.DonationCampRegistrationRepository;

import java.util.List;

@Service
public class DonationCampRegistrationService {

	@Autowired
	private DonationCampRegistrationRepository repo;

	public DonationCampRegistration registerDonor(DonationCampRegistration registration) throws Exception {
		// Check if the slot time is available
		if (isSlotAvailable(registration.getSlotTime())) {
			return this.repo.save(registration);
		} else {
			throw new Exception("Slot is already booked for the selected time.");
		}
	}

	private boolean isSlotAvailable(LocalDateTime slotTime) {
		// Query the database to check if any registration exists for the given slot time
		List<DonationCampRegistration> existingRegistrations = repo.findBySlotTime(slotTime);

		// If no existing registrations are found for the given slot time, return true (slot is available)
		return existingRegistrations.isEmpty();
	}

	public List<Object> getCount() {
		return this.repo.getCountOfGroups();
	}
}
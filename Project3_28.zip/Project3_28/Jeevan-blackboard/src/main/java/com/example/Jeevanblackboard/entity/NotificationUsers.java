package com.example.Jeevanblackboard.entity;

import java.util.List;

public class NotificationUsers {
    private List<BloodDonor> donors;
    private String message;

    // Getters and setters
    public List<BloodDonor> getDonors() {
        return donors;
    }

    public void setDonors(List<BloodDonor> donors) {
        this.donors = donors;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

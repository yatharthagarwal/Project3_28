package com.example.Jeevanblackboard.entity;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "donation_camp")
@Data
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE) 
public class DonationCamp {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int campId;
	String campName;
	String campLocation;
	LocalDate campDate;
	LocalTime campStartTime;
	LocalTime campEndTime;
	
}

package com.example.Jeevanblackboard;

import com.example.Jeevanblackboard.entity.BloodDonor;
import com.example.Jeevanblackboard.entity.DonationCamp;
import com.example.Jeevanblackboard.entity.DonationCampRegistration;
import com.example.Jeevanblackboard.entity.NotificationUsers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Component
public class BlackBoard {

    List<BloodDonor> bloodDonorList = new ArrayList<>();
    List<DonationCampRegistration> campRegistration = new ArrayList<>();

    List<DonationCamp> camps = new ArrayList<>();

    int donorCount = 1;

    int campCount = 1;
    int campRegistrationCount = 1;

    public DonationCampRegistration sendNotificationToRegisteredDonors(LocalDate date, int id) {
        List<DonationCampRegistration> r = this.getBookingsByDate(date);
        for(DonationCampRegistration d: r) {
            System.out.println("Stored donors: " + d.getDonorId() + " incoming donorId: " + id);
//            System.out.println("Notification sent to " + d.getDonorId());
            if (d.getDonorId() == id) {
                return d;
            }
        }
        return null;
    }

    public BloodDonor findDonorByUsernameAndPassword(String username, String password) {
        for(BloodDonor d: this.bloodDonorList) {
            if (d.getEmail().equals(username) && d.getPassword().equals(password)) {
                return d;
            }
        }
        return null;
    }

    public BloodDonor saveDonor(BloodDonor donor) {
        donor.setDonorId(donorCount++);
        bloodDonorList.add(donor);
        return donor;
    }

    public DonationCamp saveCamp(DonationCamp camp) {
        camp.setCampId(campCount++);
        camps.add(camp);
        return camp;
    }

    public BloodDonor getDonorById(int id) {
        for(BloodDonor d : this.bloodDonorList){
            if (d.getDonorId() == id) {
                return d;
            }
        }
        return null;
    }

    public List<BloodDonor> findAllDonors() {
        return this.bloodDonorList;
    }

    public List<BloodDonor> findByBloodGroup(String group) {
        List<BloodDonor> allDonors = this.findAllDonors();
        List<BloodDonor> donors = new ArrayList<>();
        for(BloodDonor d: allDonors) {
            if (d.getBloodGroup().equals(group)) {
                donors.add(d);
            }
        }
        return donors;
    }

    public int updateDonor(int id, BloodDonor donor) {
        for(BloodDonor d: this.bloodDonorList) {
            if (d.getDonorId() == id) {
                d.setAge(donor.getAge());
                d.setAddress(donor.getAddress());
                d.setEmail(donor.getEmail());
                d.setGender(donor.getGender());
                d.setBloodGroup(donor.getBloodGroup());
                d.setDateOfBirth(donor.getDateOfBirth());
                d.setMobileNumber(donor.getMobileNumber());
                d.setDateOfDonation(donor.getDateOfDonation());
                d.setName(donor.getName());
                return 1;
            }
        }
        return 0;
    }

    public boolean removeDonor(int id) {
        List<BloodDonor> donors = new ArrayList<>();
        boolean deleted = false;
        for(BloodDonor d: this.bloodDonorList) {
            if (d.getDonorId() != id) {
                donors.add(d);
                donorCount--;
                deleted = true;
            }
        }
        this.bloodDonorList = donors;
        return deleted;
    }

    public List<BloodDonor> findAllEligibleDonors() {
        List<BloodDonor> donors = new ArrayList<>();
        LocalDate currentDate = LocalDate.now();
        int currentYear = currentDate.getYear();
        int currentMonth = currentDate.getMonthValue();
        System.out.println("current: year " + currentYear + " month: " + currentMonth);
        for (BloodDonor d: this.bloodDonorList) {
            if (d.getDateOfDonation().getYear() < currentYear) {
                donors.add(d);
            } else if (d.getDateOfDonation().getYear() == currentYear &&
                d.getDateOfDonation().getMonthValue() < currentMonth - 6) {
                donors.add(d);
            }
        }
        return donors;
    }

    public List<BloodDonor> findAllEligibleDonorsByGroup(String group) {
        List<BloodDonor> donors = findAllEligibleDonors();
        List<BloodDonor> filteredDonor = new ArrayList<>();
        for (BloodDonor d: donors) {
            if (d.getBloodGroup().equals(group)) {
                filteredDonor.add(d);
            }
        }
        return filteredDonor;
    }

    public List<BloodDonor> findAllEligibleDonorsByLocation(String location) {
        List<BloodDonor> donors = findAllEligibleDonors();
        List<BloodDonor> filteredDonor = new ArrayList<>();
        for (BloodDonor d: donors) {
            if (d.getAddress().equals(location)) {
                filteredDonor.add(d);
            }
        }
        return filteredDonor;
    }

    public DonationCampRegistration registerDonorForCamp(DonationCampRegistration registration) throws Exception {
        if (isSlotAvailable(registration.getSlotTime())) {
            registration.setRegId(campRegistrationCount++);
            this.campRegistration.add(registration);
            return registration;
        } else {
            throw new Exception("Slot is already booked for the selected time.");
        }
    }

    private boolean isSlotAvailable(LocalDateTime slotTime) {
        for(DonationCampRegistration r: this.campRegistration) {
            if (r.getSlotTime().isEqual(slotTime)) {
                return false;
            }
        }
        return true;
//        // Query the database to check if any registration exists for the given slot time
//        List<DonationCampRegistration> existingRegistrations = repo.findBySlotTime(slotTime);
//
//        // If no existing registrations are found for the given slot time, return true (slot is available)
//        return existingRegistrations.isEmpty();
    }

    public List<DonationCampRegistration> getBookingsByDate(LocalDate date) {
        LocalDateTime startOfDay = date.atStartOfDay();
        LocalDateTime endOfDay = date.atTime(LocalTime.MAX);

        List<DonationCampRegistration> registrations = new ArrayList<>();
        for (DonationCampRegistration dcr: this.campRegistration) {
            if (dcr.getSlotTime().isBefore(endOfDay) && dcr.getSlotTime().isAfter(startOfDay)) {
                registrations.add(dcr);
            }
        }
        return registrations;
    }

    public void recommendationNotification(List<BloodDonor> donors, String message) {
        // Iterate over the list of donors and send email to each donor
        for (BloodDonor donor : donors) {
            // Assuming the donor object has an email address property
            String email = donor.getEmail(); // Implement this method to extract email from donor object
            System.out.println("Sending " + message + " to " + donor.getEmail());
            // Send email to the donor
//            sendEmail(email, message);
        }
    }

    @Override
    public String toString() {
        return "BlackBoard{" +
                "bloodDonorList=" + bloodDonorList +
                '}';
    }
}
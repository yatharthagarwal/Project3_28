package com.example.Jeevanblackboard;

import com.example.Jeevanblackboard.controller.BookingController;
import com.example.Jeevanblackboard.controller.IKnowledgeSource;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class JeevanBlackboardApplication {

	@Autowired
	private ControlComponent controlComponent;

	public static void main(String[] args) {
		SpringApplication.run(JeevanBlackboardApplication.class, args);
	}

	@PostConstruct
	public void initialize() {
		BookingController bookingController = new BookingController(controlComponent.getBlackboard());
		controlComponent.addKnowledgeSource(bookingController);
	}
}
package com.example.Jeevanblackboard.entity;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "donation_camp_registration")
@Data
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class DonationCampRegistration {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int regId;
	int donorId;
	int campId;
	LocalDateTime slotTime;
}

package com.example.Jeevanblackboard.controller;

import com.example.Jeevanblackboard.BlackBoard;
import com.example.Jeevanblackboard.entity.BloodDonor;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class RecommendationController {

    BlackBoard blackboard;
    public RecommendationController(BlackBoard blackboard){
        this.blackboard = blackboard;
    }

    @GetMapping("/fetchEligibleDonors")
    public ResponseEntity<List<BloodDonor>> fetchEligibleDonors() {
        List<BloodDonor> donors = this.blackboard.findAllEligibleDonors();
        this.blackboard.recommendationNotification(donors, "Recommended Blood Donation Camps");
        return ResponseEntity.ok(donors);
    }
}

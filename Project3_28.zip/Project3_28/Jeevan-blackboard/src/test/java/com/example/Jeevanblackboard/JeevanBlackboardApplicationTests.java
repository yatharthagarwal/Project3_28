package com.example.Jeevanblackboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JeevanBlackboardApplicationTests {

	@Test
	void contextLoads() {
	}

}

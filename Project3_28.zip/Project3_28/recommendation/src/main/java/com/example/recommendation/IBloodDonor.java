package com.example.recommendation;

public interface IBloodDonor {

    public void notifyDonor();
}

package com.example.recommendation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.recommendation.BloodDonor;

import java.util.List;

@Service
public class RecommendationService {

    @Autowired
    private RestTemplate restTemplate;

    public List<BloodDonor> fetchEligibleDonors() {
        String url = "http://localhost:4040/api/v1/donors";
        List<BloodDonor> eligibleDonors = restTemplate.getForObject(url, List.class);
        return eligibleDonors;
    }
}

package com.example.recommendation;

import java.time.LocalDate;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BloodDonor implements IBloodDonor {
    int donorId;
	String name;
	int age;
	long mobileNumber;
	String gender;
	String bloodGroup;
	String email;
	LocalDate dateOfBirth;
	LocalDate dateOfDonation;
	String address;

	@Override
	public void notifyDonor() {
		System.out.println("Email Sent");
	}
}

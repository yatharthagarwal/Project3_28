package com.example.notification.entity;

import lombok.*;

import java.time.LocalDateTime;

public class DonationCampRegistration {

	@Getter
	@Setter
	int regId;

	@Getter
	@Setter
	int donorId;

	@Getter
	@Setter
	int campId;

	@Getter
	@Setter
	LocalDateTime slotTime;
}
